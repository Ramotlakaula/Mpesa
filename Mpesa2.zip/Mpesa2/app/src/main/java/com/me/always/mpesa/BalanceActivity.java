package com.me.always.mpesa;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class BalanceActivity extends AppCompatActivity {

    public double BalanceD = 100.00;
    public double DepositEntered, NewBalance;
    TextView BalanceTV, TitleTV;
    public DecimalFormat currency = new DecimalFormat("M###,##0.00"); //decimal formatting

    public String receivedString;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_balance);

        TitleTV = (TextView) findViewById(R.id.usernameTextView);

        Bundle extras = getIntent().getExtras();

        if (extras != null) {
            receivedString = extras.getString("Username");
            TitleTV.setText(receivedString);
        }

        //set current balance of checking or savings account
        BalanceTV = (TextView) findViewById(R.id.currentTextView);
        BalanceTV.setText(String.valueOf(currency.format(BalanceD)));

        //declare deposit button
        Button DepositB = (Button) findViewById(R.id.depositButton);
        //declare user deposit input amount
        final EditText DepositET = (EditText) findViewById(R.id.depositEditText);

        //register deposit button with Event Listener class, and Event handler method
        DepositB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if deposit field is not empty, get deposit amount
                if (!TextUtils.isEmpty(DepositET.getText())) {
                    DepositEntered = Double.parseDouble(String.valueOf(DepositET.getText()));

                    if (DepositEntered != 0.00){
                        //calculate new balance
                        NewBalance = DepositEntered + BalanceD;
                        BalanceTV.setText(String.valueOf(currency.format(NewBalance)));
                    }

                }//end if
                //deposit filed is empty, prompt user to enter deposit amount
                else {

                    Toast.makeText(BalanceActivity.this, "Please enter deposit amount and try again!", Toast.LENGTH_LONG).show();
                }//end else
                //clear deposit field
                DepositET.setText(null);
            }
        });
    }

}