package com.me.always.mpesa;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class TransactionActivity extends AppCompatActivity {

    public double BalanceD = 100.00;
    public double NewBalance, transferEntered;
    TextView BalanceTV;
    public DecimalFormat currency = new DecimalFormat("M###,##0.00"); //decimal formatting


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);

        BalanceTV = (TextView) findViewById(R.id.BalanceTextView);
        BalanceTV.setText(String.valueOf(currency.format(BalanceD)));

       Button SendMoney = (Button) findViewById(R.id.sendButton);

        final EditText transferAmount = (EditText) findViewById(R.id.transferEditText);
        final EditText recepientMobile = (EditText) findViewById(R.id.mobileEditText);

        SendMoney.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if ((recepientMobile.getText().length() >= 8 && recepientMobile.getText().length() <= 10)){
                    if (!TextUtils.isEmpty(transferAmount.getText())) {

                        transferEntered = Double.parseDouble(String.valueOf(transferAmount.getText()));
                        NewBalance = BalanceD - transferEntered;
                        //BalanceD = NewBalance;

                        if (BalanceD >= transferEntered) {

                            BalanceTV.setText(String.valueOf(currency.format(NewBalance)));
                        }
                        else
                            Toast.makeText(TransactionActivity.this, "Insufficient funds! Please enter a valid transfer amount and try again!", Toast.LENGTH_LONG).show();
                    }

                    else {
                        Toast.makeText(TransactionActivity.this, "Nothing entered! Please enter transfer amount and try again!", Toast.LENGTH_LONG).show();
                    }
                }

                else if (recepientMobile.getText().length() < 0){
                    Toast.makeText(TransactionActivity.this, "You did not enter a phone number!", Toast.LENGTH_LONG).show();
                }

                else {
                    Toast.makeText(TransactionActivity.this, "Please enter a valid phone number!", Toast.LENGTH_LONG).show();
                }

                transferAmount.setText(null);
            }
        });


    }

}
