package com.me.always.mpesa;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    EditText Mobile, Password, Name ;
    Button Register;
    String NameHolder, PasswordHolder, MobileHolder;
    SQLiteHelper sqLiteHelper;
    String F_Result = "Not_Found";

    String names = "Username";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Register = (Button)findViewById(R.id.registerButton);

        Mobile = (EditText) findViewById(R.id.editMobile);
        Password = (EditText) findViewById(R.id.editPin);
        Name = (EditText) findViewById(R.id.editName);

        sqLiteHelper = new SQLiteHelper(this);

        // Adding click listener to register button.
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                NameHolder = Name.getText().toString() ;
                MobileHolder = Mobile.getText().toString();
                PasswordHolder = Password.getText().toString();

                if ((Mobile.getText().length() >= 8 || Mobile.getText().length() <= 10) && (Password.getText().length() == 4)){

                    String storedNumber = sqLiteHelper.phoneNumberExist(MobileHolder);

                    if (MobileHolder.equals(storedNumber)){
                        Toast.makeText(getApplicationContext(), "Phone Number Already Exists!", Toast.LENGTH_LONG).show();
                    }
                    else {
                        boolean trt = sqLiteHelper.insertData(NameHolder,MobileHolder,PasswordHolder);

                        if (trt){
                            // Printing toast message after done inserting.
                            Toast.makeText(RegisterActivity.this,"User Registered Successfully", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                            names = NameHolder;
                            intent.putExtra("Username", names);
                            startActivity(intent);
                        }
                    }
                }
                if (Mobile.getText().length() > 0 && Mobile.getText().length() < 8){
                    Toast.makeText(RegisterActivity.this, "Please Enter A Valid Phone Number", Toast.LENGTH_LONG).show();
                }
                if ((Password.getText().length() > 0) && (Password.getText().length() > 4 || Password.getText().length() < 4)){
                    Toast.makeText(RegisterActivity.this, "Please Enter A 4 Digit Pin Code", Toast.LENGTH_LONG).show();
                }
                // This block will execute if any of the registration EditText is empty.
                else if (Mobile.getText().length() <= 0 && Password.getText().length() <= 0){

                    // Printing toast message if any of EditText is empty.
                    Toast.makeText(RegisterActivity.this,"Please Fill All The Required Fields.", Toast.LENGTH_LONG).show();

                }

                // Method to check Mobile is already exists or not.
                //CheckingMobileAlreadyExistsOrNot();

                // Empty EditText After done inserting process.
                EmptyEditTextAfterDataInsert();


            }
        });

    }

    // Empty editText after done inserting process method.
    public void EmptyEditTextAfterDataInsert(){

        Name.getText().clear();

        Mobile.getText().clear();

        Password.getText().clear();

    }

    // Checking mobile is already exists or not.
    /*public void CheckingMobileAlreadyExistsOrNot(){

        // Opening SQLite database write permission.
        sqLiteDatabaseObj = sqLiteHelper.getWritableDatabase();

        // Adding search mobile query to cursor.
        cursor = sqLiteDatabaseObj.query(SQLiteHelper.TABLE_NAME, null, " " + SQLiteHelper.Table_Column_2_Mobile + "=?", new String[]{MobileHolder}, null, null, null);

        while (cursor.moveToNext()) {

            if (cursor.isFirst()) {

                cursor.moveToFirst();

                // If Mobile is already exists then Result variable value set as Email Found.
                F_Result = "Mobile Found";

                // Closing cursor.
                cursor.close();
            }
        }

        // Calling method to check final result and insert data into SQLite database.
        CheckFinalResult();

    }*/


    // Checking result
    public void CheckFinalResult(){

        // Checking whether mobile is already exists or not.
        if(F_Result.equalsIgnoreCase("Mobile Found"))
        {

            // If mobile is exists then toast msg will display.
            Toast.makeText(RegisterActivity.this,"Mobile Already Exists",Toast.LENGTH_LONG).show();

        }

        F_Result = "Not_Found" ;

    }

}
