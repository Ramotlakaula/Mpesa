package com.me.always.mpesa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ServicesActivity extends AppCompatActivity {

    //declare variables for message, checking and savings balance
    String receivedString;
    public String chkBalance;

    Button buttonBalance, buttonSend, buttonQuit;
    String names = "Username";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services);

        buttonBalance = (Button) findViewById(R.id.balanceButton);
        buttonSend = (Button) findViewById(R.id.buttonSend);
        buttonQuit = (Button) findViewById(R.id.buttonLogout);

        Bundle extras = getIntent().getExtras();

        //receive welcome msg from LoginActivity
        if (extras != null) {
            receivedString = extras.getString("Username");
            Toast.makeText(ServicesActivity.this, receivedString, Toast.LENGTH_LONG).show();
        }

        buttonBalance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ServicesActivity.this, BalanceActivity.class);
                names = receivedString;
                intent.putExtra("Username", names);
                startActivity(intent);
            }
        });

        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ServicesActivity.this, TransactionActivity.class);
                startActivity(intent);
            }
        });

        buttonQuit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ServicesActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
